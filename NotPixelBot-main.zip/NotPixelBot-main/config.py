url = "https://notpx.app/api/v1"

accounts = [
    "initData user=%7B%22id%22%3A1431751865%2C%22first_name%22%3A%22%D0%A1%D0%B0%D0%BC%D0%B0%D1%82%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22samat_que%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=7167255971921566636&chat_type=sender&auth_date=1725640632&hash=ba0523b1c46d3f8059d39a159dc2d97fedaf02227f81151e914947d9871ec4a5",
    "initData user=%7B%22id%22%3A1485105394%2C%22first_name%22%3A%22smn%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22smy_name%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-466847157591453414&chat_type=sender&auth_date=1725719211&hash=4a195b4fae4603c763d0bdd6d0418c2a231d6d43e21e3cbc473bb5ce37f1cff4",
    "initData user=%7B%22id%22%3A6305318621%2C%22first_name%22%3A%22Geekman%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22geekX0%22%2C%22language_code%22%3A%22ru%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=5438044166153497780&chat_type=sender&auth_date=1725639004&hash=5a5e5ccd670f852758fb186f6e084e26305a90f1080df0c550abf4b82437f99c",
    "initData user=%7B%22id%22%3A1945380517%2C%22first_name%22%3A%22dzhalil%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22ZiganshinDzhalil%22%2C%22language_code%22%3A%22ru%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=6472019921340618234&chat_type=sender&auth_date=1725640368&hash=ed419dc960a0019322880b54c2215d517f56d48aae580e89877637a2704885b1",
    "initData user=%7B%22id%22%3A1173441935%2C%22first_name%22%3A%22Gabitov%22%2C%22last_name%22%3A%22Shamil%22%2C%22username%22%3A%22gabitg%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-6154619231545217215&chat_type=sender&auth_date=1725720286&hash=8ab50b583fbe57d392c1be1b6e9df963b870610b80bf53354b9894916f81315a",
    "initData user=%7B%22id%22%3A2021588404%2C%22first_name%22%3A%22%D0%A4%D0%BB%D1%8E%D1%80%22%2C%22last_name%22%3A%22%22%2C%22username%22%3A%22torpoll%22%2C%22language_code%22%3A%22ru%22%2C%22allows_write_to_pm%22%3Atrue%7D&chat_instance=-4647950755282267985&chat_type=private&start_param=f1173441935&auth_date=1725644625&hash=a66eed8a98756165ff3336bef5e182878205a86e496c491156deddd5c5bbd1f8"
]

# ACTIVITY
WAIT = 180 * 3
DELAY = 0.01

# IMAGE
WIDTH = 1000
HEIGHT = 1000
MAX_HEIGHT = 50
